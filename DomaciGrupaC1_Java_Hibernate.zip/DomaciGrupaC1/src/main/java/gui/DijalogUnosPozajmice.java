package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.ClanCrud;
import crud.KnjigaCrud;
import crud.PozajmitiCrud;
import model.Dm64924Clan;
import model.Dm64924Knjiga;
import model.Dm64924Pozajmiti;
import model.Dm64924PozajmitiPK;

import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DijalogUnosPozajmice extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private ClanCrud cc = new ClanCrud();
	private KnjigaCrud kc = new KnjigaCrud();
	private PozajmitiCrud pc = new PozajmitiCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DijalogUnosPozajmice dialog = new DijalogUnosPozajmice();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DijalogUnosPozajmice() {
		setTitle("Unos pozajmice");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblClan = new JLabel("Izaberite clana:");
		lblClan.setBounds(10, 29, 158, 14);
		contentPanel.add(lblClan);
		
		JLabel lblKnjiga = new JLabel("Izaberite knjigu:");
		lblKnjiga.setBounds(10, 71, 158, 14);
		contentPanel.add(lblKnjiga);
		
		JLabel lblDatumUzimanja = new JLabel("Unesite datum uzimanja:");
		lblDatumUzimanja.setBounds(10, 115, 158, 14);
		contentPanel.add(lblDatumUzimanja);
		
		JLabel lblDatumVracanja = new JLabel("Unesite datum vracanja:");
		lblDatumVracanja.setBounds(10, 157, 158, 14);
		contentPanel.add(lblDatumVracanja);
		
		DateFormat format = new SimpleDateFormat("dd-MMMM-yy");
		
		JFormattedTextField ftfDatumUzimanja = new JFormattedTextField(format);
		ftfDatumUzimanja.setBounds(178, 112, 228, 20);
		contentPanel.add(ftfDatumUzimanja);
		
		JFormattedTextField ftfDatumVracanja = new JFormattedTextField(format);
		ftfDatumVracanja.setBounds(178, 154, 228, 20);
		contentPanel.add(ftfDatumVracanja);
		
		JComboBox<Dm64924Clan> cbClan = new JComboBox<>();
		cbClan.setBounds(178, 25, 228, 22);
		contentPanel.add(cbClan);
		List<Dm64924Clan> clanovi = cc.listClanovi();
		for (Dm64924Clan c : clanovi) {
			cbClan.addItem(c);
		}
		
		JComboBox<Dm64924Knjiga> cbKnjiga = new JComboBox<>();
		cbKnjiga.setBounds(178, 67, 228, 22);
		contentPanel.add(cbKnjiga);
		List<Dm64924Knjiga> knjige = kc.listKnjige();
		for (Dm64924Knjiga k : knjige) {
			cbKnjiga.addItem(k);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnUnesiPozajmicu = new JButton("Unesi pozajmicu");
				btnUnesiPozajmicu.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Dm64924Clan clan = cbClan.getItemAt(cbClan.getSelectedIndex());
						Dm64924Knjiga knjiga = cbKnjiga.getItemAt(cbKnjiga.getSelectedIndex());
						Date du = (Date) ftfDatumUzimanja.getValue();
						Date dv = (Date) ftfDatumVracanja.getValue();
						
						Dm64924PozajmitiPK pk = new Dm64924PozajmitiPK();
						pk.setClanIdc(clan.getIdc());
						pk.setKnjigaIdk(knjiga.getIdk());
						
						Dm64924Pozajmiti pozajmica = new Dm64924Pozajmiti();
						pozajmica.setId(pk);
						pozajmica.setDm64924Clan(clan);
						pozajmica.setDm64924Knjiga(knjiga);
						pozajmica.setDu(du);
						pozajmica.setDv(dv);
						
						pc.insertPozajmica(pozajmica);
					}
				});
				btnUnesiPozajmicu.setActionCommand("OK");
				buttonPane.add(btnUnesiPozajmicu);
				getRootPane().setDefaultButton(btnUnesiPozajmicu);
			}
			{
				JButton btnOdustani = new JButton("Odustani");
				btnOdustani.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnOdustani.setActionCommand("Cancel");
				buttonPane.add(btnOdustani);
			}
		}
	}
}
