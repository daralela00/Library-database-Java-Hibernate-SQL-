package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.ClanCrud;
import crud.KnjigaCrud;
import model.Dm64924Clan;
import model.Dm64924Knjiga;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class DijalogPrikazKnjiga extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private ClanCrud cc = new ClanCrud();
	private KnjigaCrud kc = new KnjigaCrud();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DijalogPrikazKnjiga dialog = new DijalogPrikazKnjiga();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DijalogPrikazKnjiga() {
		setTitle("Prikaz Knjiga");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel, BorderLayout.NORTH);
			{
				JLabel lblClan = new JLabel("Izaberite clana:");
				panel.add(lblClan);
			}
			{
				JComboBox<Dm64924Clan> cbClan = new JComboBox<>();
				panel.add(cbClan);
				{
					JButton btnPrikazi = new JButton("Prikazi");
					btnPrikazi.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Dm64924Clan c = cbClan.getItemAt(cbClan.getSelectedIndex());
							List<Dm64924Knjiga> knjige = kc.listKnjigeUpit(c);
							
							TableModelKnjige tmk = new TableModelKnjige(knjige);
							table.setModel(tmk);
						}
					});
					panel.add(btnPrikazi);
				}
				{
					JScrollPane scrollPane = new JScrollPane();
					contentPanel.add(scrollPane, BorderLayout.CENTER);
					{
						table = new JTable();
						scrollPane.setViewportView(table);
					}
				}
				List<Dm64924Clan> clanovi = cc.listClanovi();
				for (Dm64924Clan c : clanovi) {
					cbClan.addItem(c);
				}
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnOdustani = new JButton("Odustani");
				btnOdustani.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnOdustani.setActionCommand("Cancel");
				buttonPane.add(btnOdustani);
			}
		}
	}

}
