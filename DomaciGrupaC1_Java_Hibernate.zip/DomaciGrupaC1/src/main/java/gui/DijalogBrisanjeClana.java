package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.ClanCrud;
import model.Dm64924Clan;

import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JComboBox;

public class DijalogBrisanjeClana extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private ClanCrud cc = new ClanCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DijalogBrisanjeClana dialog = new DijalogBrisanjeClana();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DijalogBrisanjeClana() {
		setTitle("Brisanje clana");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblClan = new JLabel("Izaberite clana:");
		lblClan.setBounds(10, 100, 156, 14);
		contentPanel.add(lblClan);
		
		JComboBox<Dm64924Clan> cbClan = new JComboBox<Dm64924Clan>();
		cbClan.setBounds(176, 96, 230, 22);
		contentPanel.add(cbClan);
		List<Dm64924Clan> clanovi = cc.listClanovi();
		for (Dm64924Clan c : clanovi) {
			cbClan.addItem(c);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnObrisiClana = new JButton("Obrisi clana");
				btnObrisiClana.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Dm64924Clan clan = cbClan.getItemAt(cbClan.getSelectedIndex());
						
						cc.deleteClan(clan);
					}
				});
				btnObrisiClana.setActionCommand("OK");
				buttonPane.add(btnObrisiClana);
				getRootPane().setDefaultButton(btnObrisiClana);
			}
			{
				JButton btnOdustani = new JButton("Odustani");
				btnOdustani.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnOdustani.setActionCommand("Cancel");
				buttonPane.add(btnOdustani);
			}
		}
	}
}
