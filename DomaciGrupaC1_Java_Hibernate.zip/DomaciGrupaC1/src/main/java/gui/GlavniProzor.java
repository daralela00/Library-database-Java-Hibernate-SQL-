package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GlavniProzor {

	private JFrame frmGlavniProzor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GlavniProzor window = new GlavniProzor();
					window.frmGlavniProzor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GlavniProzor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmGlavniProzor = new JFrame();
		frmGlavniProzor.setTitle("Glavni prozor");
		frmGlavniProzor.getContentPane().setBackground(Color.WHITE);
		frmGlavniProzor.setBounds(100, 100, 450, 300);
		frmGlavniProzor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmGlavniProzor.getContentPane().setLayout(null);
		
		JButton btnUnosClana = new JButton("Unos clana");
		btnUnosClana.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DijalogUnosClana duc = new DijalogUnosClana();
				duc.setVisible(true);
			}
		});
		btnUnosClana.setBounds(10, 53, 159, 45);
		frmGlavniProzor.getContentPane().add(btnUnosClana);
		
		JButton btnUnosPozajmice = new JButton("Unos pozajmice");
		btnUnosPozajmice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DijalogUnosPozajmice dup = new DijalogUnosPozajmice();
				dup.setVisible(true);
			}
		});
		btnUnosPozajmice.setBounds(265, 53, 159, 45);
		frmGlavniProzor.getContentPane().add(btnUnosPozajmice);
		
		JButton btnBrisanjeClana = new JButton("Brisanje clana");
		btnBrisanjeClana.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DijalogBrisanjeClana dbc = new DijalogBrisanjeClana();
				dbc.setVisible(true);
			}
		});
		btnBrisanjeClana.setBounds(10, 161, 159, 45);
		frmGlavniProzor.getContentPane().add(btnBrisanjeClana);
		
		JButton btnPrikazKnjiga = new JButton("Prikaz knjiga 2024");
		btnPrikazKnjiga.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DijalogPrikazKnjiga dpk = new DijalogPrikazKnjiga();
				dpk.setVisible(true);
			}
		});
		btnPrikazKnjiga.setBounds(265, 161, 159, 45);
		frmGlavniProzor.getContentPane().add(btnPrikazKnjiga);
	}
}
