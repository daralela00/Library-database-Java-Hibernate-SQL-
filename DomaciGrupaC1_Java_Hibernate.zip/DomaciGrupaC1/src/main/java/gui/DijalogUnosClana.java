package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.ClanCrud;
import model.Dm64924Clan;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DijalogUnosClana extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfIme;
	private JTextField tfPrezime;
	private ClanCrud cc = new ClanCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DijalogUnosClana dialog = new DijalogUnosClana();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DijalogUnosClana() {
		setTitle("Unos clana");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblIme = new JLabel("Unesite ime:");
		lblIme.setBounds(10, 33, 119, 27);
		contentPanel.add(lblIme);
		
		JLabel lblPrezime = new JLabel("Unesite prezime:");
		lblPrezime.setBounds(10, 113, 119, 27);
		contentPanel.add(lblPrezime);
		
		tfIme = new JTextField();
		tfIme.setBounds(176, 35, 230, 23);
		contentPanel.add(tfIme);
		tfIme.setColumns(10);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(176, 116, 230, 20);
		contentPanel.add(tfPrezime);
		tfPrezime.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnUnesiClana = new JButton("Unesi clana");
				btnUnesiClana.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String ime = tfIme.getText();
						String prezime = tfPrezime.getText();
						
						Dm64924Clan c = new Dm64924Clan(ime, prezime);
						
						cc.insertClan(c);
					}
				});
				btnUnesiClana.setActionCommand("OK");
				buttonPane.add(btnUnesiClana);
				getRootPane().setDefaultButton(btnUnesiClana);
			}
			{
				JButton btnOdustani = new JButton("Odustani");
				btnOdustani.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						tfIme.setText("");
						tfPrezime.setText("");
						setVisible(false);
					}
				});
				btnOdustani.setActionCommand("Cancel");
				buttonPane.add(btnOdustani);
			}
		}
	}
}
