package gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Dm64924Knjiga;

public class TableModelKnjige extends AbstractTableModel{
	
	private List<Dm64924Knjiga> knjige = null;
	String kolone[] = {"naslov", "godina izdanja", "br. dos. primeraka", "kategorija"};
	
	public TableModelKnjige(List<Dm64924Knjiga> knjige) {
		this.knjige = knjige;
	}

	@Override
	public int getRowCount() {
		return knjige.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Dm64924Knjiga k = knjige.get(rowIndex);
		switch (columnIndex) {
		case 0: return k.getNaslov();
		case 1: return k.getGodizd();
		case 2: return k.getBrdp();
		case 3: return k.getKat();
		}
		return null;
	}
	
	public String getColumnName (int i) {
		return kolone[i];
	}

}
