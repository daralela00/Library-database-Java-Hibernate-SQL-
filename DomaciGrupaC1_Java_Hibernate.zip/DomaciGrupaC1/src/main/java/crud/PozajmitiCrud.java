package crud;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.Dm64924Pozajmiti;
import utils.PersistenceUtil;

public class PozajmitiCrud {
	
	public void insertPozajmica(Dm64924Pozajmiti p) {
		EntityManager em = PersistenceUtil.getEntityManager();
		EntityTransaction et = null;
		try {
			et = em.getTransaction();
			et.begin();
			
			em.persist(p);
			
			em.flush();
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (et != null) {
				et.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}
}
