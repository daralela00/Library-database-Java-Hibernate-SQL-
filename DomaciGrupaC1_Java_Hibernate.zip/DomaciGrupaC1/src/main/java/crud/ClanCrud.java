package crud;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.Dm64924Clan;
import utils.PersistenceUtil;

public class ClanCrud {
	
	public void insertClan(Dm64924Clan c) {
		EntityManager em = PersistenceUtil.getEntityManager();
		EntityTransaction et = null;
		try {
			et = em.getTransaction();
			et.begin();
			
			em.persist(c);
			
			em.flush();
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (et != null) {
				et.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}
	
	public void deleteClan(Dm64924Clan c) {
		EntityManager em = PersistenceUtil.getEntityManager();
		EntityTransaction et = null;
		try {
			et = em.getTransaction();
			et.begin();
			
			c = em.merge(c);
			em.remove(c);
			
			em.flush();
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (et != null) {
				et.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}
	
	public List<Dm64924Clan> listClanovi() {
		EntityManager em = PersistenceUtil.getEntityManager();
		String upit = "select c from Dm64924Clan c order by c.idc";
		List<Dm64924Clan> clanovi = em.createQuery(upit).getResultList();
		em.close();
		return clanovi;
	}
}
