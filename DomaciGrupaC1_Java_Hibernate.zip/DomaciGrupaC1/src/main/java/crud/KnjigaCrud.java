package crud;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import model.Dm64924Clan;
import model.Dm64924Knjiga;
import utils.PersistenceUtil;

public class KnjigaCrud {
	
	public List<Dm64924Knjiga> listKnjige() {
		EntityManager em = PersistenceUtil.getEntityManager();
		String upit = "select k from Dm64924Knjiga k order by k.idk";
		List<Dm64924Knjiga> knjige = em.createQuery(upit).getResultList();
		em.close();
		return knjige;
	}
	
	public List<Dm64924Knjiga> listKnjigeUpit(Dm64924Clan c) {
		EntityManager em = PersistenceUtil.getEntityManager();
		String upit = "select k from Dm64924Knjiga k join k.dm64924Pozajmitis p where p.dm64924Clan.idc = :x and p.du >= :startDate and p.du < :endDate";
		Query q = em.createQuery(upit);
		
		LocalDate start = LocalDate.of(2024, 1, 1);
	    LocalDate end = LocalDate.of(2025, 1, 1);
	    
	    q.setParameter("x", c.getIdc());
		q.setParameter("startDate", java.sql.Date.valueOf(start));
		q.setParameter("endDate", java.sql.Date.valueOf(end));
		
		List<Dm64924Knjiga> knjige = q.getResultList();
		em.close();
		return knjige;
	}

}
