package model;

import java.io.Serializable;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the DM64924_CLAN database table.
 * 
 */
@Entity
@Table(name="DM64924_CLAN")
@NamedQuery(name="Dm64924Clan.findAll", query="SELECT d FROM Dm64924Clan d")
public class Dm64924Clan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="DM64924_CLAN_IDC_GENERATOR", sequenceName="DM64924_CLAN_PK")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DM64924_CLAN_IDC_GENERATOR")
	private long idc;

	private String ime;

	private String prezime;

	//bi-directional many-to-one association to Dm64924Pozajmiti
	@OneToMany(mappedBy="dm64924Clan")
	private List<Dm64924Pozajmiti> dm64924Pozajmitis;

	public Dm64924Clan() {
		this.dm64924Pozajmitis = new ArrayList<Dm64924Pozajmiti>();
	}
	
	@Override
	public String toString() {
		return ime + " " + prezime;
	}

	public Dm64924Clan(String ime, String prezime) {
		this();
		this.ime = ime;
		this.prezime = prezime;
	}

	public long getIdc() {
		return this.idc;
	}

	public void setIdc(long idc) {
		this.idc = idc;
	}

	public String getIme() {
		return this.ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return this.prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public List<Dm64924Pozajmiti> getDm64924Pozajmitis() {
		return this.dm64924Pozajmitis;
	}

	public void setDm64924Pozajmitis(List<Dm64924Pozajmiti> dm64924Pozajmitis) {
		this.dm64924Pozajmitis = dm64924Pozajmitis;
	}

	public Dm64924Pozajmiti addDm64924Pozajmiti(Dm64924Pozajmiti dm64924Pozajmiti) {
		getDm64924Pozajmitis().add(dm64924Pozajmiti);
		dm64924Pozajmiti.setDm64924Clan(this);

		return dm64924Pozajmiti;
	}

	public Dm64924Pozajmiti removeDm64924Pozajmiti(Dm64924Pozajmiti dm64924Pozajmiti) {
		getDm64924Pozajmitis().remove(dm64924Pozajmiti);
		dm64924Pozajmiti.setDm64924Clan(null);

		return dm64924Pozajmiti;
	}

}