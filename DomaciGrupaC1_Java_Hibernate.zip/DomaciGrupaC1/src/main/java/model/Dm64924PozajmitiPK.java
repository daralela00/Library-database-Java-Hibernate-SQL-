package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DM64924_POZAJMITI database table.
 * 
 */
@Embeddable
public class Dm64924PozajmitiPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CLAN_IDC", insertable=false, updatable=false)
	private long clanIdc;

	@Column(name="KNJIGA_IDK", insertable=false, updatable=false)
	private long knjigaIdk;

	public Dm64924PozajmitiPK() {
	}
	public long getClanIdc() {
		return this.clanIdc;
	}
	public void setClanIdc(long clanIdc) {
		this.clanIdc = clanIdc;
	}
	public long getKnjigaIdk() {
		return this.knjigaIdk;
	}
	public void setKnjigaIdk(long knjigaIdk) {
		this.knjigaIdk = knjigaIdk;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof Dm64924PozajmitiPK)) {
			return false;
		}
		Dm64924PozajmitiPK castOther = (Dm64924PozajmitiPK)other;
		return 
			(this.clanIdc == castOther.clanIdc)
			&& (this.knjigaIdk == castOther.knjigaIdk);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.clanIdc ^ (this.clanIdc >>> 32)));
		hash = hash * prime + ((int) (this.knjigaIdk ^ (this.knjigaIdk >>> 32)));
		
		return hash;
	}
}