package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the DM64924_POZAJMITI database table.
 * 
 */
@Entity
@Table(name="DM64924_POZAJMITI")
@NamedQuery(name="Dm64924Pozajmiti.findAll", query="SELECT d FROM Dm64924Pozajmiti d")
public class Dm64924Pozajmiti implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Dm64924PozajmitiPK id;

	@Temporal(TemporalType.DATE)
	private Date du;

	@Temporal(TemporalType.DATE)
	private Date dv;

	//bi-directional many-to-one association to Dm64924Clan
	@ManyToOne
	@JoinColumn(name="CLAN_IDC", insertable = false, updatable = false)
	private Dm64924Clan dm64924Clan;

	//bi-directional many-to-one association to Dm64924Knjiga
	@ManyToOne
	@JoinColumn(name="KNJIGA_IDK", insertable = false, updatable = false)
	private Dm64924Knjiga dm64924Knjiga;

	public Dm64924Pozajmiti() {
	}

	public Dm64924PozajmitiPK getId() {
		return this.id;
	}

	public void setId(Dm64924PozajmitiPK id) {
		this.id = id;
	}

	public Date getDu() {
		return this.du;
	}

	public void setDu(Date du) {
		this.du = du;
	}

	public Date getDv() {
		return this.dv;
	}

	public void setDv(Date dv) {
		this.dv = dv;
	}

	public Dm64924Clan getDm64924Clan() {
		return this.dm64924Clan;
	}

	public void setDm64924Clan(Dm64924Clan dm64924Clan) {
		this.dm64924Clan = dm64924Clan;
	}

	public Dm64924Knjiga getDm64924Knjiga() {
		return this.dm64924Knjiga;
	}

	public void setDm64924Knjiga(Dm64924Knjiga dm64924Knjiga) {
		this.dm64924Knjiga = dm64924Knjiga;
	}

}