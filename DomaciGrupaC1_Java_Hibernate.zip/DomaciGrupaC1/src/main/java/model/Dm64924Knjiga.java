package model;

import java.io.Serializable;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the DM64924_KNJIGA database table.
 * 
 */
@Entity
@Table(name="DM64924_KNJIGA")
@NamedQuery(name="Dm64924Knjiga.findAll", query="SELECT d FROM Dm64924Knjiga d")
public class Dm64924Knjiga implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="DM64924_KNJIGA_IDK_GENERATOR", sequenceName="DM64924_KNJIGA_PK")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DM64924_KNJIGA_IDK_GENERATOR")
	private long idk;

	private int brdp;

	private int godizd;

	private String kat;

	private String naslov;

	//bi-directional many-to-one association to Dm64924Pozajmiti
	@OneToMany(mappedBy="dm64924Knjiga")
	private List<Dm64924Pozajmiti> dm64924Pozajmitis;

	public Dm64924Knjiga() {
		this.dm64924Pozajmitis = new ArrayList<Dm64924Pozajmiti>();
	}

	@Override
	public String toString() {
		return naslov;
	}

	public long getIdk() {
		return this.idk;
	}

	public void setIdk(long idk) {
		this.idk = idk;
	}

	public int getBrdp() {
		return this.brdp;
	}

	public void setBrdp(int brdp) {
		this.brdp = brdp;
	}

	public int getGodizd() {
		return this.godizd;
	}

	public void setGodizd(int godizd) {
		this.godizd = godizd;
	}

	public String getKat() {
		return this.kat;
	}

	public void setKat(String kat) {
		this.kat = kat;
	}

	public String getNaslov() {
		return this.naslov;
	}

	public void setNaslov(String naslov) {
		this.naslov = naslov;
	}

	public List<Dm64924Pozajmiti> getDm64924Pozajmitis() {
		return this.dm64924Pozajmitis;
	}

	public void setDm64924Pozajmitis(List<Dm64924Pozajmiti> dm64924Pozajmitis) {
		this.dm64924Pozajmitis = dm64924Pozajmitis;
	}

	public Dm64924Pozajmiti addDm64924Pozajmiti(Dm64924Pozajmiti dm64924Pozajmiti) {
		getDm64924Pozajmitis().add(dm64924Pozajmiti);
		dm64924Pozajmiti.setDm64924Knjiga(this);

		return dm64924Pozajmiti;
	}

	public Dm64924Pozajmiti removeDm64924Pozajmiti(Dm64924Pozajmiti dm64924Pozajmiti) {
		getDm64924Pozajmitis().remove(dm64924Pozajmiti);
		dm64924Pozajmiti.setDm64924Knjiga(null);

		return dm64924Pozajmiti;
	}

}