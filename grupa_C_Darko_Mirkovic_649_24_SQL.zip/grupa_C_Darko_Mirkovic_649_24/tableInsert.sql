-- Popunjavanje tabele autor

INSERT INTO dm64924_autor (IDA, IME, PREZIME)
VALUES (1, 'Leona', 'Dikin');

INSERT INTO dm64924_autor (IDA, IME, PREZIME)
VALUES (2, 'Entoni', 'Horovic');

INSERT INTO dm64924_autor (IDA, IME, PREZIME)
VALUES (3, 'Donato', 'Karizi');

INSERT INTO dm64924_autor (IDA, IME, PREZIME)
VALUES (4, 'Mark', 'Tven');

INSERT INTO dm64924_autor (IDA, IME, PREZIME)
VALUES (5, 'Danijel', 'Defo');

-- Popunjavanje tabele knjiga

INSERT INTO dm64924_knjiga (IDK, NASLOV, GODIZD, BRDP, KAT)
VALUES (1, 'Igra', 2021, 10, 'Triler');

INSERT INTO dm64924_knjiga (IDK, NASLOV, GODIZD, BRDP, KAT)
VALUES (2, 'Morijarti', 2014, 15, 'Triler');

INSERT INTO dm64924_knjiga (IDK, NASLOV, GODIZD, BRDP, KAT)
VALUES (3, 'Saptac', 2012, 12, 'Triler');

INSERT INTO dm64924_knjiga (IDK, NASLOV, GODIZD, BRDP, KAT)
VALUES (4, 'Tom Sojer', 2020, 7, 'Decja');

INSERT INTO dm64924_knjiga (IDK, NASLOV, GODIZD, BRDP, KAT)
VALUES (5, 'Robinzon Kruso', 2021, 4, 'Decja');

-- Popunjavanje tabele clan

INSERT INTO dm64924_clan (IDC, IME, PREZIME)
VALUES (1, 'Pera', 'Peric');

INSERT INTO dm64924_clan (IDC, IME, PREZIME)
VALUES (2, 'Mika', 'Mikic');

INSERT INTO dm64924_clan (IDC, IME, PREZIME)
VALUES (3, 'Darko', 'Janicic');

INSERT INTO dm64924_clan (IDC, IME, PREZIME)
VALUES (4, 'Nikola', 'Milankovic');


-- Popunjavanje tabele napisati

INSERT INTO dm64924_napisati (AUTOR_IDA, KNJIGA_IDK)
VALUES (1, 1);

INSERT INTO dm64924_napisati (AUTOR_IDA, KNJIGA_IDK)
VALUES (2, 2);

INSERT INTO dm64924_napisati (AUTOR_IDA, KNJIGA_IDK)
VALUES (3, 3);

INSERT INTO dm64924_napisati (AUTOR_IDA, KNJIGA_IDK)
VALUES (4, 4);

INSERT INTO dm64924_napisati (AUTOR_IDA, KNJIGA_IDK)
VALUES (5, 5);

-- Popunjavanje tabele pozajmiti

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (1, 1, TO_DATE('2025-04-02', 'YYYY-MM-DD'), NULL);

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (1, 3, TO_DATE('2025-04-02', 'YYYY-MM-DD'), NULL);

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (1, 5, TO_DATE('2025-04-02', 'YYYY-MM-Dd'), NULL);

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (2, 2, TO_DATE('2025-02-15', 'YYYY-MM-DD'), TO_DATE('2025-03-15', 'YYYY-MM-DD'));

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (2, 4, TO_DATE('2025-02-15', 'YYYY-MM-DD'), TO_DATE('2025-03-15', 'YYYY-MM-DD'));

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (3, 1, TO_DATE('2025-01-07', 'YYYY-MM-DD'), TO_DATE('2025-04-22', 'YYYY-MM-DD'));

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (3, 2, TO_DATE('2025-01-07', 'YYYY-MM-DD'), TO_DATE('2025-04-22', 'YYYY-MM-DD'));

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (4, 3, TO_DATE('2025-02-24', 'YYYY-MM-DD'), NULL);

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (4, 4, TO_DATE('2025-02-24', 'YYYY-MM-DD'), NULL);

INSERT INTO dm64924_pozajmiti (CLAN_IDC, KNJIGA_IDK, DU, DV)
VALUES (4, 5, TO_DATE('2025-02-24', 'YYYY-MM-DD'), NULL);