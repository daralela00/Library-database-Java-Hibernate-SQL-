-- Zadatak 5: SQL upit (Koknretno u ovom primer za broj zaduzenih knjiga uzet je broj 2. Tu je ubacena vrednost na mestu gde je u zadatku prazno polje.)

SELECT dm64924_clan.ime, dm64924_clan.prezime, COUNT(*) as POZKNJIGE
FROM dm64924_clan, dm64924_pozajmiti
WHERE dm64924_clan.idc = dm64924_pozajmiti.clan_idc AND dm64924_pozajmiti.dv IS NULL
GROUP BY dm64924_clan.ime, dm64924_clan.prezime
HAVING COUNT(*) > 2;

-- Zadatak 6: SQL upit (Koknretno za ovaj primer je uzeta kategorija 'Decja' i broj meseci 6. Tu su ubacene vrednosti na mesto gde je u zadatku prazno polje.)

UPDATE dm64924_knjiga 
SET dm64924_knjiga.brdp = dm64924_knjiga.brdp + 1
WHERE dm64924_knjiga.kat like 'Decja'
    AND EXISTS (SELECT 1
                FROM dm64924_pozajmiti
                WHERE dm64924_knjiga.idk = dm64924_pozajmiti.knjiga_idk AND (SYSDATE - dm64924_pozajmiti.du < 6*30));
                
-- Zadatak 7: SQL upit (Koknretno za ovaj primer je uzeto ime clana 'Pera'.Tu je ubacena vrednost na mesto gde je u zadatku prazno polje.)

DELETE FROM dm64924_clan
WHERE dm64924_clan.ime like 'Pera';
                           